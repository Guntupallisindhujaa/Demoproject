export interface PensionDetail{
    name:String,
    dateOfBirth:Date,
    pan:String,
    pensionType:String,
    pensionAmount:number

}