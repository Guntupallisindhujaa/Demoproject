export interface PensionerInput{
    aadharNumber:number,
    name:String,
    dateOfBirth:Date,
    pan:String,
    pensionType:String,

}