export interface PensionerDetail{
    aadharNumber:number,
    name:String,
    dateOfBirth:Date,
    pan:String,
    salaryEarned:number,
    allowances:number,
    pensionType:String,
    bankName:String,
    accountNumber:number,
    bankType:String
}