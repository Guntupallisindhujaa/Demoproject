package com.pension.process.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class ProcessPensionResponse {
	private int processPensionStatusCode;
}