insert into users (id, password, user_name) values (1, 'sindhu', 'sindhu');
insert into users (id, password, user_name) values (2, 'password', 'test@user');
