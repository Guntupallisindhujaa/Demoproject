package com.authorization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.authorization.AuthorizationMicroserviceApplication;

@SpringBootTest
class AuthorizatiionMicroserviceApplicationTests {

	@Test
	void main() {
		AuthorizationMicroserviceApplication.main(new String[] {});
	}
}