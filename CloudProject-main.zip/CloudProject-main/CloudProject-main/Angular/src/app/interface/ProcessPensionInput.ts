export interface ProcessPensionInput{
    aadharNumber:number,
     pensionAmount:number,
     bankCharge:number
}