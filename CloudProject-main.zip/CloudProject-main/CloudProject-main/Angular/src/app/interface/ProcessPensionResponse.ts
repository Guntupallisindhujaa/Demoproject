export interface ProcessPensionResponse{
    statusCode:number;
}