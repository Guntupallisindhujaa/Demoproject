insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (890005635647,'pavi','1996-01-07','SBIOC34253',89000,7000,'self','Indian Bank',3696453455,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (765647365647,'Viky','1998-10-13','ABTOC34253',60000,9000,'self','Indian Bank',3696434565,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (345423876757,'Abi','1998-01-21','DFMYE14759',54000,2000,'self','HDFC',6749563835,'private');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (420559429029,'Parthik','1999-12-03','BSDPS1495K',29000,1200,'self','SBI',9029486523,'private');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (656756476757,'Shubham','1999-11-28','PCASD1234Q',27000,10000,'family','ICICI',8130234567,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (566456785634,'kumar','1999-09-21','PCQAZ1285Q',30000,12000,'family','SBI',7296235677,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (432567345637,'karthi','1998-01-24','DSPDZ1287G',40000,12002,'family','SBI',9366235677,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (213456765765,'siva','1998-12-05','ABDFM67983',55000,2000,'family','ICICI',4370656756,'private');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (410023455765,'somou','1999-05-22','SHTOC34253',65000,8000,'family','HDFC',1197456756,'public');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (875647376767,'shri','1999-04-23','UYTO109874',26000,1000,'self','HSBC',7987653423,'private');

insert into pensioner (aadhar, name, dob, pan,salary,allowances,pension,bank,accnumber,banktype) values (210034523767,'kiriti','1998-07-15','MBHER12436',29500,1100,'self','HDFC',7217653423,'private');