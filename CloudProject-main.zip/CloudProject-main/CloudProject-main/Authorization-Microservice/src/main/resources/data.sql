insert into users (id, password, user_name) values (1, 'sundar', 'sundar');
insert into users (id, password, user_name) values (2, 'password', 'test@user');
